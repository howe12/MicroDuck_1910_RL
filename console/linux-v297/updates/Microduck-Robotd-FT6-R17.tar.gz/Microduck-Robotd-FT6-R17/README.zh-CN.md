# V276 / control.118 可选完整服务包

稳定的自有编号/测试会话不再被service_operation状态误判为正在切换。命令执行和等待首帧反馈分开：匹配的新命令完成后可显式选择其他目标，当前模式高亮与页面导航仍等实际确认，不作乐观跳转；旧请求的迟到回调不清除新命令的忙状态。

新鲜确认的正常总线停止优先显示中性“总线已停止”，不拿残留robotd错误代替当前停止状态。手动暂停与总线停止区分，真正意外的native/连接错误保留。连接、所有者、扫描、实际忙状态及运动标定门槛保持。

本轮仅修改app.js、four-pages.js、service.js和startup-status.js，CSS、资产、全部生产Python及ZERO逻辑逐字节保持V275。当前22项HTTP/状态矩阵及133条DOM检查通过，覆盖12个有向切换、连续模式循环和真实Store fixture；独立与root审核批准。只执行本轮窄范围验证，未重跑旧业务大全。

worker保持81873 bytes，SHA256 `e720ae3a5ec2306f00e5366f1b190b0704a4978984d875fcf17e28dd34c803d6`；组件ID保持 `6207860842cccf7a035ee5591bc4c3a146981e8043c68a60f3429007336bf0ef`。音频、helper、模型、Policy、波特率与全部容量上限保持；本轮UI修复不需更新ZERO运行逻辑。

原生robotd仅将唯一只读BUILD117等长更新为BUILD118，只变偏移621676，执行段及其余字节保持，未重编译。见 `DEPLOYMENT-IDENTITY.json`。实机及浏览器像素未验收，Known-Good不更新。下一步唯一主任务：在参考ZERO / 浏览器验收连续模式切换及正常停止提示。

证据：`console/verification/v276/results.json`（源码根）或 `verification/v276/results.json`（中控目录）。
