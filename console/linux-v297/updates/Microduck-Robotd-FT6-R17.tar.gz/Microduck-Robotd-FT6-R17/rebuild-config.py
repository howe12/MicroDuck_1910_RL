#!/usr/bin/env python3
"""Preserve installation settings during explicit installation only."""
import argparse
import copy
import json
import os
from pathlib import Path
import stat
import tomllib
from configure import atomic_write, dumps

BASE=Path(__file__).resolve().parent
CONFIG=Path('/etc/robot/feetech-ft5/robotd.toml')
CALIBRATION=CONFIG.with_name('hd1910-calibration.toml')
MIDPOINT_MARKER_NAME='hd1910-midpoint-invalidated.json'
MAX_MIDPOINT_MARKER_BYTES=4096

def saved_path(path):return path.with_name(path.stem+'.saved'+path.suffix)

def midpoint_invalidated(path):
    """An explicit midpoint reset must survive installation's seed recovery."""
    marker=path.with_name(MIDPOINT_MARKER_NAME)
    try:fd=os.open(marker,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW|os.O_NONBLOCK)
    except FileNotFoundError:return set()
    except OSError as exc:raise ValueError('中位校准失效记录无法安全读取：'+str(exc)) from None
    try:
        with os.fdopen(fd,'rb') as stream:
            info=os.fstat(stream.fileno())
            if (not stat.S_ISREG(info.st_mode) or info.st_uid!=os.geteuid()
                    or info.st_mode&0o022 or info.st_size>MAX_MIDPOINT_MARKER_BYTES):
                raise ValueError('中位校准失效记录的文件类型、所有者、权限或长度无效')
            raw=stream.read(MAX_MIDPOINT_MARKER_BYTES+1)
        if len(raw)>MAX_MIDPOINT_MARKER_BYTES:raise ValueError('中位校准失效记录过长')
        data=json.loads(raw)
        ids=data.get('invalidated_ids') if isinstance(data,dict) else None
        if (not isinstance(data,dict) or set(data)!={'version','invalidated_ids'}
                or type(data.get('version')) is not int or data['version']!=1
                or not isinstance(ids,list) or len(ids)>253
                or any(type(ident) is not int or not 0<=ident<254 or ident==200 for ident in ids)
                or len(set(ids))!=len(ids)):
            raise ValueError('中位校准失效记录的格式无效')
        return set(ids)
    except (OSError,UnicodeError,json.JSONDecodeError) as exc:
        raise ValueError('中位校准失效记录无法读取或解析，未恢复旧标定') from exc

def read_config(path, kind):
    """Check recovery inputs, without changing valid per-robot values."""
    try:
        data=tomllib.loads(path.read_text(encoding='utf-8'))
        if kind=='params':
            if not data or not isinstance(data.get('policy'),dict):return None
            for key in ('bus','control','safety'):
                if key in data and not isinstance(data[key],dict):return None
            if not isinstance(data['policy'].get('walk'),str):return None
            data['policy'].pop('r17_inference_scale',None)
        else:
            joints=data.get('joints')
            if not isinstance(joints,list) or len(joints)!=15:return None
            names=set();ids=set()
            for joint in joints:
                if not isinstance(joint,dict):return None
                name=joint.get('name');ident=joint.get('id');zero=joint.get('zero_raw');direction=joint.get('direction')
                if not isinstance(name,str) or name in names:return None
                if type(ident) is not int or not 0<=ident<254 or ident==200 or ident in ids:return None
                if type(zero) is not int or not 0<=zero<=4095 or type(direction) is not int or direction not in (-1,1):return None
                names.add(name);ids.add(ident)
        return data
    except (OSError,ValueError,UnicodeError):return None

def source_data(path, kind, base):
    fallback=base/('robotd-profile.toml' if kind=='params' else 'hd1910-calibration.template.toml')
    original=(Path('/etc/robot/robotd.toml'),) if path==CONFIG else ()
    for candidate in (path,saved_path(path),*original,fallback):
        data=read_config(candidate,kind)
        if data is not None:
            if kind=="calibration" and candidate==fallback:
                data["motion_enabled"]=False
                for joint in data["joints"]:joint["calibrated"]=False
            if candidate!=path:print(f'按完整来源重建：{path} ← {candidate}',flush=True)
            return data
    raise ValueError(f'没有可用于重建的完整配置：{path}')

def prepare(directory, params=CONFIG, calibration=CALIBRATION, base=BASE):
    # Stage before service mutation; malformed old files must not abort replacement.
    values=(source_data(params,'params',base),prepare_calibration(calibration,base))
    for name,data in zip(('robotd.toml','hd1910-calibration.toml'),values):
        atomic_write(directory/name,dumps(data))

def prepare_calibration(path,base=BASE):
    """Installation only: restore known assembled robot values where no saved ones exist.

    Later restarts/failure recovery never reapply the model snapshot. Calibrated
    local joints (and their limits) always win, then saved local data, then the
    explicitly supplied robot snapshot. A fresh all-unmarked template also has
    a placeholder IMU orientation, even if its default was just confirmed.
    Explicit midpoint invalidation preserves that local row until capture.
    """
    invalidated=midpoint_invalidated(path)
    current=source_data(path,'calibration',base)
    saved=read_config(saved_path(path),'calibration') or {}
    seed=read_config(base/'hd1910-calibration.robot.toml','calibration')
    if seed is None:raise ValueError('缺少随模型核对的本机装配标定')
    data=copy.deepcopy(current)
    has_local=any(r.get('calibrated') is True or r['id'] in invalidated for r in current['joints'])
    saved_rows={r['name']:r for r in saved.get('joints',[])}
    seed_rows={r['name']:r for r in seed['joints']}
    restored=[]
    for i,row in enumerate(data['joints']):
        if row.get('calibrated') is True:continue
        if row['id'] in invalidated:
            data['motion_enabled']=False
            continue
        candidate=saved_rows.get(row['name'],{})
        if candidate.get('calibrated') is not True:candidate=seed_rows[row['name']]
        if candidate['id']!=row['id']:raise ValueError('本机标定 ID 与随包装配记录不符：'+row['name'])
        data['joints'][i]=copy.deepcopy(candidate);restored.append(row['name'])
    imu_source=None
    if not has_local or data.get('imu_mount_verified') is not True:
        imu_source=saved if saved.get('imu_mount_verified') is True and any(r.get('calibrated') is True for r in saved.get('joints',[])) else seed
        for name in ('imu_mount_quat','imu_mount_verified'):data[name]=copy.deepcopy(imu_source[name])
    if restored or imu_source is not None:
        data['motion_enabled']=False
        print('安装恢复装配标定：补齐 '+str(len(restored))+' 个关节；头部 ID 33 零位 '+str(data['joints'][8]['zero_raw'])+'；IMU '+('已恢复' if imu_source is not None else '保留本机设置'),flush=True)
    return data

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    actions=parser.add_mutually_exclusive_group(required=True)
    actions.add_argument('--prepare',type=Path)
    args=parser.parse_args()
    prepare(args.prepare)
