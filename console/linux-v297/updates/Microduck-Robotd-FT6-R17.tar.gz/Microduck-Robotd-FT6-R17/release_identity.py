"""One release identity shared by the console and bundled firmware."""
BUILD = '1fa843-feetech-ft6-control.118'
CONSOLE_VERSION = '1.0.276'
OFFICIAL_VERSION = '0.15.1'
